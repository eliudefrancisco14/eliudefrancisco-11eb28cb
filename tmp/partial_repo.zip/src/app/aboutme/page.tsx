import About from "@/components/app/About";

export default function Page() {
  return (
    <section>
      <About />
    </section>
  );
}
