import TalkToMe from "@/components/app/TalkToMe";

export default function Page() {
  return (
    <section>
      <TalkToMe />
    </section>
  );
}
