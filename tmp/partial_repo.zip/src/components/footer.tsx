export default function Footer() {
  return (
    <footer className="mb-16">
      
      <p className="mt-8 text-neutral-900 dark:text-neutral-300">
        © {new Date().getFullYear()} Feito com ❤️ e ☕ por Eliude Francisco
      </p>
    </footer>
  )
}
